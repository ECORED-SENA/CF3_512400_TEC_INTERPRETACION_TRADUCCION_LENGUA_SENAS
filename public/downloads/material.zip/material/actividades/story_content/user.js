function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6kIhNUdV8dx":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

