function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6ehhCuu4dYv":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

