function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5anbw85Gf2I":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

